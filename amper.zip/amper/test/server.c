#include <stdio.h>

#include "dhmp.h"

int main()
{
	dhmp_server_init();
	dhmp_server_destroy();
	return 0;
}
